const toggleButton = document.getElementsByClassName("input_checkbox")[0];
const changeTextElement1 = document.getElementsByClassName("contant1_heading")[0]; 
const changeTextElement2 = document.getElementsByClassName("contant2_heading")[0]; 
const changeTextElement3 = document.getElementsByClassName("contant3_heading")[0]; 
let isToggled = false;


toggleButton.addEventListener("click", function() {
    isToggled = !isToggled;
    
    if (isToggled) {
        toggleButton.classList.add("active");
        changeTextElement1.innerText = "$240";
        changeTextElement2.innerText = "$1080";
        changeTextElement3.innerText = "$1800";
    } else {
        toggleButton.classList.remove("active");
        changeTextElement1.innerText = "$20"; 
        changeTextElement2.innerText = "$90";
        changeTextElement3.innerText = "$150"; 
    }
});